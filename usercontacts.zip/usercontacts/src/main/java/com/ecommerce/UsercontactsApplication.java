package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsercontactsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsercontactsApplication.class, args);
	}

}
